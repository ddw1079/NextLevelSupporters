package DonationDAO;

import java.util.List;

public abstract class BaseDAO<T> {

	// 모든 항목을 가져오는 메서드 (구체적으로 어떤 항목을 가져올지 하위 클래스에서 구현)
    public abstract List<T> getAllItems();
    
    /*
     *	RAccept2DAO :  BaseDAO<DonationDTO>를 상속 /
		getAllItems()를 수혜자의 미수락 후원 목록 조회용으로 구현
     * 구현 메서드 
		List<DonationDTO> getDonationsByReceiver(String receiverId)==> 로그인한 수혜자의 미수락 후원 내역 가져오기
		boolean acceptDonation(int donationId) ==> 특정 후원 내역을 수락 처리 (수혜자가 ‘받기’ 누른 경우)
		int getTotalReceivedAmount(String receiverId) ==> 누적 수령 금액 (선택사항)
     */
}
