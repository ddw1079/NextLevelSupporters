package DonationVO;

public class HistoryVO implements BaseVO {

}
