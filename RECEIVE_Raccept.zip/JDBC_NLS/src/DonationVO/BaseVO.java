package DonationVO;

import java.io.Serializable;

public interface BaseVO extends Serializable {
    // 필수적인 데이터 처리 메서드를 정의
}
