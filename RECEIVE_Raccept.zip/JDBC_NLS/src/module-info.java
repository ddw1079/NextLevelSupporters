/**
 * 
 */
/**
 * 
 */
module JDBC_NLS {
	requires java.sql;
}