/**
 * 
 */
/**
 * 
 */
module RECEIVER2 {
	requires java.desktop;
}